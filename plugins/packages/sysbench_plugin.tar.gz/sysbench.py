"""Standalone Sysbench plugin package for distribution."""

from workload_generators.sysbench_generator import SysbenchPlugin

PLUGIN = SysbenchPlugin()
